
import json
import boto3

def lambda_handler(event, context):
    sns_message = event['Records'][0]['Sns']['Message']
    print("Received SNS message:", sns_message)
    
    # Initialize the SNS client
    sns_client = boto3.client('sns')
    
    # Define the recipient's phone number
    recipient_phone_number = '+918860020619'  # Replace with actual phone number
    
    # Logic to handle different types of notifications
    if 'health issue' in sns_message:
        # Handle health issue notification
        sns_client.publish(
            PhoneNumber=recipient_phone_number,
            Message=f"Health Issue Alert: {sns_message}"
        )
    elif 'scaling event' in sns_message:
        # Handle scaling event notification
        sns_client.publish(
            PhoneNumber=recipient_phone_number,
            Message=f"Scaling Event Alert: {sns_message}"
        )
    elif 'high traffic' in sns_message:
        # Handle high traffic notification
        sns_client.publish(
            PhoneNumber=recipient_phone_number,
            Message=f"High Traffic Alert: {sns_message}"
        )
    else:
        # Handle general notifications
        sns_client.publish(
            PhoneNumber=recipient_phone_number,
            Message=f"General Alert: {sns_message}"
        )
